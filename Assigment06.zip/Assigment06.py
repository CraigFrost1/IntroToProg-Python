#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   Craig Frost
# Date:  Sept 16, 2017
# ChangeLog: (Craig Frost, 11/22/18- Module 06)
#   RRoot, 09/16/2017, Created Script

#-------------------------------------------------#

#-- Data --#
# declare variables and constants
# objFile = An object that represents a file
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)

#-- Processing --#
# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user

# Step 3
# Display all todo items to user

# Step 4
# Add a new item to the list/Table

# Step 5
# Remove a new item to the list/Table

# Step 6
# Save tasks to the ToDo.txt file

# Step 7
# Exit program
#----------------------------------------------- Data -----------------------------------------------#
# declare variables and constants
objFileName = "C:\_PythonClass\Assignment06\Todo.txt"
strData = ""
dicRow = {}
lstTable = []
#------------------------------------------- Input/Output -------------------------------------------#
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
class IO: #Start Class IO
    @staticmethod
    def inMenu(): # Input- menu choice (1-5)
        return str(input("Please select an option from the menu (1-5): "))
    @staticmethod
    def inAddItem(): # Input- add task and priority to the list
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        return strTask, strPriority
    @staticmethod
    def inRemoveItem(): # Input- removes a new item from the list
        strKeyToRemove = input("Which TASK would you like removed? - ")
        return strKeyToRemove
    @staticmethod
    def inSaveList(): # Input- Save tasks to the ToDo.txt file
        return(str(input("Would you like to save this data to a file (y/n)? ".strip().lower())))
    @staticmethod
    def outMenu():  # Output- Display a menu of choices to the user
        print("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
    @staticmethod
    def outCurrentItems(lstTable): # Output- Show the current items in the table
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
    @staticmethod
    def outAddItemStatus(itemAdded): #Output- Displays feedback when an item is added
        if (itemAdded == True): print("Task was added successfully")
        else: print("Task was NOT added successfully")
    @staticmethod
    def outDeleteItemStatus(itemDeleted): #Output- Displays feedback when an item is deleted
        if (itemDeleted == True): print ("Task was deleted successfully")
        else: print("Task was NOT deleted successfully")
    @staticmethod #Output- Displays a message when exiting the program
    def outThankYou():
        print("Program Exiting. Thank you for using")
#End Class IO
# --------------------------------- DATA PROCESSING ------------------------------------#
class DataProcessing: #Start class Data Processing
    @staticmethod
    def loadData(objFileName, lstTable): #Defines a function to load data from text file into a dictionary
        objFile = open(objFileName, "r")
        for line in objFile: #Iterates through each line in the text file
            strData = line.split(",") # readline() reads a line of the data into 2 elements
            dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()} #Assigns data to task and priority based on position in text file
            lstTable.append(dicRow) #Appends dicRow to lstTable
        objFile.close() #closes text file
    @staticmethod
    def addItem(strTask, strPriority, lstTable): #Allows user to add an item to the lstTable
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow) #Appends dicRow to lstTable
    @staticmethod
    def deleteItem(strKeyToRemove, lstTable): #Allows the user to delete an item
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list
                del lstTable[intRowNumber]
                blnItemRemoved = True
            # end if
            intRowNumber += 1
            return blnItemRemoved
    @staticmethod
    def saveToFile(objFileName, lstTable): #Allows the user to save list to text file
        objFile = open(objFileName, "w")
        for dicRow in lstTable:
            objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
        objFile.close()
# End Class Data processing
# -------------------------------------- MAIN ----------------------------------------#
DataProcessing.loadData(objFileName, lstTable) #Loads data from text file
while True:
    IO.outMenu() #Displays the menu to the user
    strChoice = IO.inMenu().strip() #Receives menu selection input from user and strips the value
    if strChoice == '1': #if the user selects "1"....
        IO.outCurrentItems(lstTable) #then current items in the lsttable are displayed
        continue #The loop continues (Menue and selection input are displayed.)
    elif strChoice == '2': #If the user selects "2"...
        strTask, strPriority = IO.inAddItem() #Variables strTask and strPriority are assigned through the inAddItem input function
        DataProcessing.addItem(strTask, strPriority, lstTable) #Variables strTask and strPriority are appended to the lstTable
        IO.outCurrentItems(lstTable) #The updated lstTable is displayed
        continue #The loop continues (Menue and selection input are displayed.
    elif strChoice == '3': #If the user selects "3"...
        strKeyToRemove = IO.inRemoveItem() #strKeyToRemove variable is assigned through the inRemovgeItem input
        blnStatus = DataProcessing.deleteItem(strKeyToRemove, lstTable) #Key is deleted in the lstTable
        IO.outDeleteItemStatus(blnStatus) #Delete status displays the user
        IO.outCurrentItems(lstTable) #updated lstTable displays to user
        continue #The loop continues (Menue and selection input are displayed.
    elif strChoice == '4': #If the user selects "4"...
        if'y' == IO.inSaveList(): #If the user enters "y" then...
            DataProcessing.saveToFile(objFileName, lstTable) #the lstTable is saved to the text file
        else:
            pass #if the user does not enter "y", then the list is not saved...
        continue #and the loop continues
    elif strChoice == '5': #If the user selects "5"
        IO.outThankYou() #A thank you message is displayed
        break #The loop breaks and the program exits








