#-------------------------------------------------#
# Title: Python Pickling
# Dev:   Craig Frost
# Date:  December 3, 2018
# ChangeLog: (Craig Frost, 12/3/18, Initial Creation)
#-------------------------------------------------#

#-- Data --#
#pickeList- A dictionary that acts as a 'table' of rows

#-- Input/Output --#
#Output: List displays to user
#Input: User is asked if they would like to package the displayed list (y/n)
#Output (y): The user is notified that the list has been pickled
#Output (n): The user is notified that the list has not been pickled
#Input: The user is asked if they would now like to un-package the pickled list (y/n)
#Ouput (y): The un-packed list is displayed
#Output (n): The program exits

#-- Processing --#
#Import the pickle module
#Create a list with three items
#Dump the list into "Assignment07Pickle" binary file
#Load the pickle bas into a list

import pickle
#---------------------------------------- Data ----------------------------------------#
# declare variables and constants
pickleList = ['Craig', 'Python', 'Pickle']
pickleDump = ()
data = ()
# ---------------------------------------I/O ------------------------------------------#
class IO: #Starts IO Class
    @staticmethod
    def listDisplay():
        print("The List to Pickle is:" + str(pickleList))
    @staticmethod
    def packageList():
        package = str(input("Would you like to package the following List? (Enter 'y/n'): ")).strip()
        return package
    @staticmethod
    def packageOutput():
        print("the list has been pickled")
    @staticmethod
    def unPackageList():
        unPackage = str(input("Would you now like to un-package the list? (Enter 'y/n'): "))
        return unPackage
    @staticmethod
    def displayUnpack():
        print("The list has been un-packed")
    @staticmethod
    def displayNotPickle():
        print("List not Pickled")
#End class IO
# --------------------------------- DATA PROCESSING ------------------------------------#
class packagePickle: #Packages the PickleList into a binary file
    @staticmethod
    def pickleDump():
        pickleDump = open('Assignment07Pickle', 'wb') #Opens the "Assignment07Pickle" file in binary write mode and assigns it to variable pickleDump
        pickle.dump(pickleList, pickleDump) #Dumps the pickleList into binary file
        pickleDump.close() #Closes the binary file

class loadPickle(): #Loads the binary file into a list
    @staticmethod
    def pickleLoad():
        cnt = 0 #Start count at 0
        pickleLoad = open('Assignment07Pickle', 'rb') #Opens "Assignment07Pickle" file as PickleLoad in reading binary mode.
        data = pickle.load(pickleLoad) #Loads the data from the file into "data" list
        for item in data: #iterates through each item in the list and...
            print('The data ', cnt, ' is : ', item) #prints each line
            cnt += 1 #and increments a count starting at 0
#End Class Data Processing
# -------------------------------------- MAIN ----------------------------------------#
IO.listDisplay() #Displays list to user
if "y" == IO.packageList(): #Asks users if they would like to package the list using pickle.
    packagePickle.pickleDump() #if user types in 'y' the list is pickled
    IO.packageOutput() #And feedback is displayed to the user
    if "y" == IO.unPackageList(): #The user is then asked if they would like to unpack the binary file
        loadPickle.pickleLoad() #if 'y', The binary file is unpacked
        IO.displayUnpack() #if 'y', the user is provided feedback
else:
    IO.displayNotPickle() #if not 'y' the user is presented with a message