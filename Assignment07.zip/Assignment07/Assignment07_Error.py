#-------------------------------------------------#
# Title: Python Error Handling
# Dev:   Craig Frost
# Date:  December 3, 2018
# ChangeLog: (Craig Frost, 12/3/18, Initial Creation)
#-------------------------------------------------#

#-- Data --#
#number1- An integer to add
#number2- An integer to add

#-- Input/Output --#
#Enter value for number 1
#Enter value for number 2


#-- Processing --#
#If the two numbers entered are integers, return the sum...  Otherwise, throw an error.

#---------------------------------------- Data ----------------------------------------#
# declare variables and constants
number1 = 0
number2 = 0

# ---------------------------------------I/O ------------------------------------------#
class IO:
    @staticmethod
    def sumIntegersInput1():
        number1 = input("Enter a number to add: ") # Get input and store in a variable. Enter number from 1-10
        return number1
    @staticmethod
    def sumIntegersInput2():
        number2 = input("Enter a second number to add: ") # Get input and store in a variable. Enter number from 1-10
        return number2
#End class IO
# --------------------------------- DATA PROCESSING ------------------------------------#
class Processing:
    @staticmethod
    def sumIntegers():
        try:
            total = int(number1) + int(number2) #Sum two integers
            print("Your total is " + str(total)) #Print the total
        except:
            print("You did not enter a number for one of the variable!") #If integers are not entered, throw an error
#End class Data Processing
# --------------------------------------- Main------------------------------------------#
while True: #Creates a loop
    number1 = IO.sumIntegersInput1() #Assigns input to number variable 1
    number2 = IO.sumIntegersInput2() #Assigns input to number variable 2
    Processing.sumIntegers() #Adds both integer variables


