#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   CFrost
# Date:  Nov 17, 2018
# ChangeLog: (Craig Frost, Nov 17,2018, Initial Development)
#-------------------------------------------------#

#-- Data --#
objFile = open("C:\\_PythonClass\\Assignment05\\ToDo.txt", "a")
strChoice = "" #Capture the user option selection
objFileName = "C:\_PythonClass\Assignment05\ToDo.txt"
strData = ""
dicRow = {}
lstTable = []

#-- Processing --#
# Step 1 - Load data from a file
for row in open(objFileName):  # When the program starts, load each "row" of data into a dictionary
    key, value = row.split(",")
    dicRow[key] = value
# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()

    # Step 3 -Show the current items in the table
    if (strChoice.strip() == '1'):
        print(dicRow)
        continue
    # Step 4 - Add a new item to the list/Table
    # add a term-definition pair
    elif(strChoice.strip() == '2'):
        newItem = input("Enter 'To-Do' Item:" )
        if newItem not in dicRow:
            newItemPriority = input("\nEnter Item Priority: ")
            dicRow[newItem] = newItemPriority
            print("\n", newItem, "has been added.")
        else:
            print("\nThat item already exists! Add a different item")
        continue
    # Step 5 - Remove a new item to the list/Table
    elif(strChoice == '3'):
        delItem = input("What 'To-Do' item would you like to delete?: ")
        if delItem in dicRow:
            del dicRow[delItem]
            print("\nItem is deleted", delItem)
        else:
            print("\nCannot Delete!", delItem, "doesn't exist in the 'To-Do' List.")
        continue
    # Step 6 - Save tasks to the ToDo.txt file
    elif(strChoice == '4'):
        print(dicRow)
        objFile.write("\n" + str(newItem) + "," + str(newItemPriority))
        objFile.close()
        print("Successfully updated 'To-Do' List")
        continue
    elif (strChoice == '5'):
        print("Thank you for using the 'To-Do' application!")
        break #and Exit the program

